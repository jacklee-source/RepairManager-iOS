# 手機維修管家 iOS 專案

- 原生 SwiftUI，最低 iOS 16。
- 支援新增、編輯、刪除、搜尋維修紀錄。
- 欄位包括品牌、型號、IMEI、日期、狀態、故障、零件、成本、收費、保固及備註。
- 資料儲存在 iPhone App 沙盒 JSON 檔案。

## Windows 11 編譯
Windows 無法執行 Xcode。可上傳 GitHub，使用本專案的 GitHub Actions macOS runner 編譯。此 ZIP 是原始碼，不是已簽名 IPA。

## macOS 編譯
安裝 Xcode、XcodeGen，在專案根目錄執行 `xcodegen generate`，再以 Xcode 開啟 `RepairManager.xcodeproj`。
真機安裝需用自己的 Apple ID 簽署。此版本暫未實作照片附件、JSON 匯入及雲端同步。
